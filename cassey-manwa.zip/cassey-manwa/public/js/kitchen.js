const NEXT = { new: ['preparing', 'Start preparing'], preparing: ['ready', 'Mark ready'], ready: ['completed', 'Complete / served'] };
let known = new Set(), first = true;

function beep() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator(); o.frequency.value = 880; o.connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.25);
  } catch (e) {}
}

async function load() {
  const { orders } = await api('/kitchen/orders');
  for (const s of ['new', 'preparing', 'ready']) {
    $('#c-' + s).innerHTML = orders.filter((o) => o.status === s).map((o) => `
      <div class="ticket ${s}">
        <div class="row between"><b>${esc(o.order_no)}</b><span class="tag">${o.service_type === 'dine_in' ? 'Dine-in' + (o.table_no ? ' · ' + esc(o.table_no) : '') : 'Takeout'}</span></div>
        <div class="muted">${esc(o.customer_name)} · ${fmtDT(o.paid_at)}</div>
        <ul>${o.items.map((i) => `<li><b>${i.qty}×</b> ${esc(i.name)}</li>`).join('')}</ul>
        ${o.notes ? `<p>📝 ${esc(o.notes)}</p>` : ''}
        <button class="btn" style="width:100%" data-id="${o.id}" data-to="${NEXT[s][0]}">${NEXT[s][1]}</button>
      </div>`).join('') || '<p class="muted">—</p>';
  }
  const ids = new Set(orders.filter((o) => o.status === 'new').map((o) => o.id));
  if (!first && [...ids].some((id) => !known.has(id))) beep();
  known = ids; first = false;
  $('#upd').textContent = 'Updated ' + new Date().toLocaleTimeString('en-PH', { timeZone: 'Asia/Manila' });
}

document.addEventListener('click', async (e) => {
  if (e.target.closest('[data-act="logout"]')) return logout();
  const b = e.target.closest('[data-to]'); if (!b) return;
  b.disabled = true;
  try { await api(`/kitchen/orders/${b.dataset.id}/status`, { method: 'PATCH', body: { status: b.dataset.to } }); await load(); }
  catch (err) { toast(err.message, 'err'); load().catch(() => {}); }
});

(async () => {
  const u = await requireStaff(['kitchen', 'cashier', 'admin']);
  $('#who').textContent = u.name;
  await load().catch((e) => toast(e.message, 'err'));
  setInterval(() => load().catch(() => {}), 5000);
})();
