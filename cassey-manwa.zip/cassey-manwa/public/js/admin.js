const main = $('#main');
let CATS = [];
let tab = 'dashboard';
const ROLE_OPTS = ['admin', 'cashier', 'kitchen', 'customer'].map((r) => ({ v: r, l: r[0].toUpperCase() + r.slice(1) }));
const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Manila' });
const table = (head, rows) => `<div class="tablewrap"><table><thead><tr>${head.map((h) => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.join('') || `<tr><td colspan="${head.length}" class="muted center">Nothing here yet.</td></tr>`}</tbody></table></div>`;
const bars = (rows, key = 'period') => {
  const max = Math.max(1, ...rows.map((r) => Number(r.sales)));
  return `<div class="bars">${rows.map((r) => `<div class="bar" title="${esc(r[key])}: ${peso(r.sales)}"><span>${peso(r.sales).replace('.00', '')}</span><i style="height:${Math.max(2, (Number(r.sales) / max) * 100)}%"></i><span>${esc(String(r[key]).slice(5))}</span></div>`).join('')}</div>`;
};

const TABS = {
  async dashboard() {
    const d = await api('/admin/dashboard');
    main.innerHTML = `<h2>Dashboard</h2><div class="stats">
      <div class="card stat">Today's sales<b>${peso(d.today.sales)}</b></div>
      <div class="card stat">Paid orders today<b>${d.today.orders}</b></div>
      <div class="card stat">In kitchen<b>${d.in_kitchen}</b></div>
      <div class="card stat">Awaiting payment<b>${d.awaiting_payment}</b></div>
      <div class="card stat">Low-stock items<b>${d.low_stock}</b></div></div>
      <div class="card"><h3 style="margin-top:0">Last 7 days</h3>${d.last7.length ? bars(d.last7) : '<p class="muted">No paid orders yet.</p>'}</div>`;
  },

  async orders() {
    const f = { status: '', payment_status: '', from: '', to: '' };
    main.innerHTML = `<h2>Orders & payments</h2><form class="row" id="of">
      <select name="status"><option value="">All statuses</option>${Object.entries(STATUS_LABEL).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select>
      <select name="payment_status"><option value="">Paid & unpaid</option><option value="paid">Paid</option><option value="unpaid">Unpaid</option></select>
      <input type="date" name="from" style="width:auto"><input type="date" name="to" style="width:auto"><button class="btn">Filter</button></form><br><div id="ol"></div>`;
    async function load() {
      const qs = new URLSearchParams(Object.fromEntries(Object.entries(f).filter(([, v]) => v))).toString();
      const { orders } = await api('/admin/orders?' + qs);
      $('#ol').innerHTML = table(['Order', 'Created', 'Source', 'Type', 'Customer', 'Total', 'Payment', 'Status', ''], orders.map((o) => `<tr>
        <td><b>${esc(o.order_no)}</b></td><td>${fmtDT(o.created_at)}</td><td>${o.source === 'pos' ? 'POS' : 'Online'}</td><td>${o.service_type === 'dine_in' ? 'Dine-in' : 'Takeout'}</td>
        <td>${esc(o.customer_name)}</td><td>${peso(o.total)}</td><td>${payTag(o.payment_status, o.payment_method)}</td><td>${statusTag(o.status)}</td>
        <td><button class="btn small ghost" data-act="view-order" data-id="${o.id}">Details</button></td></tr>`));
    }
    $('#of').addEventListener('submit', (e) => { e.preventDefault(); for (const k of Object.keys(f)) f[k] = e.target.elements[k].value; load().catch((er) => toast(er.message, 'err')); });
    await load();
  },

  async products() {
    const [{ products }, { categories }] = await Promise.all([api('/admin/products'), api('/admin/categories')]);
    CATS = categories; window.__products = products;
    main.innerHTML = `<div class="row between"><h2>Products</h2><button class="btn" data-act="add-product">+ Add product</button></div>` +
      table(['Name', 'Category', 'Price', 'Available', 'Stock', ''], products.map((p) => `<tr><td><b>${esc(p.name)}</b></td><td>${esc(p.category)}</td><td>${peso(p.price)}</td>
        <td>${p.available ? '<span class="tag ok">Yes</span>' : '<span class="tag err">Hidden</span>'}</td><td>${p.track_stock ? p.stock_qty : '—'}</td>
        <td><button class="btn small ghost" data-act="edit-product" data-id="${p.id}">Edit</button> <button class="btn small danger" data-act="del-product" data-id="${p.id}">Delete</button></td></tr>`));
  },

  async categories() {
    const { categories } = await api('/admin/categories'); CATS = categories;
    main.innerHTML = `<div class="row between"><h2>Categories</h2><button class="btn" data-act="add-cat">+ Add category</button></div>` +
      table(['Name', 'Sort order', ''], categories.map((c) => `<tr><td><b>${esc(c.name)}</b></td><td>${c.sort_order}</td>
        <td><button class="btn small ghost" data-act="edit-cat" data-id="${c.id}">Edit</button> <button class="btn small danger" data-act="del-cat" data-id="${c.id}">Delete</button></td></tr>`));
    window.__cats = categories;
  },

  async inventory() {
    const [{ products }, { movements }] = await Promise.all([api('/admin/products'), api('/admin/inventory/movements')]);
    main.innerHTML = `<h2>Inventory</h2><p class="muted">Items with stock tracking are deducted automatically when an order is paid. Turn tracking on from the product editor, or by adjusting stock below.</p>` +
      table(['Product', 'Tracked', 'In stock', 'Alert at', ''], products.map((p) => `<tr><td><b>${esc(p.name)}</b></td><td>${p.track_stock ? 'Yes' : 'No'}</td>
        <td>${p.track_stock ? `<span class="tag ${p.stock_qty <= 0 ? 'err' : p.stock_qty <= p.low_stock_level ? 'warn' : 'ok'}">${p.stock_qty}</span>` : '—'}</td><td>${p.track_stock ? p.low_stock_level : '—'}</td>
        <td><button class="btn small" data-act="adjust" data-id="${p.id}" data-name="${esc(p.name)}">Adjust stock</button></td></tr>`)) +
      `<h3>Recent stock movements</h3>` + table(['When', 'Product', 'Change', 'Reason', 'By'], movements.map((m) => `<tr><td>${fmtDT(m.created_at)}</td><td>${esc(m.name)}</td><td>${m.change_qty > 0 ? '+' : ''}${m.change_qty}</td><td>${esc(m.reason)}</td><td>${esc(m.by_user || 'system')}</td></tr>`));
  },

  async users() {
    const { users } = await api('/admin/users'); window.__users = users;
    main.innerHTML = `<div class="row between"><h2>Employees & customers</h2><button class="btn" data-act="add-user">+ Add staff</button></div>` +
      table(['Name', 'Email', 'Phone', 'Role', 'Active', ''], users.map((u) => `<tr><td><b>${esc(u.name)}</b></td><td>${esc(u.email)}</td><td>${esc(u.phone || '')}</td><td><span class="tag">${esc(u.role)}</span></td>
        <td>${u.active ? '<span class="tag ok">Active</span>' : '<span class="tag err">Disabled</span>'}</td><td><button class="btn small ghost" data-act="edit-user" data-id="${u.id}">Edit</button></td></tr>`));
  },

  async reports() {
    main.innerHTML = `<h2>Sales reports</h2><form class="row" id="rf">
      <select name="period"><option value="daily">Daily</option><option value="weekly">Weekly</option><option value="monthly">Monthly</option></select>
      <label class="muted" style="margin:0">From</label><input type="date" name="from" style="width:auto"><label class="muted" style="margin:0">To</label><input type="date" name="to" style="width:auto">
      <button class="btn">Run report</button><a class="btn ghost" id="csv" href="#">Download CSV</a></form><br><div id="rr"></div>`;
    const qs = () => { const f = $('#rf').elements; return new URLSearchParams(Object.fromEntries(['period', 'from', 'to'].map((k) => [k, f[k].value]).filter(([, v]) => v))).toString(); };
    async function run() {
      const { rows, top } = await api('/admin/reports/sales?' + qs());
      const sum = rows.reduce((a, r) => ({ s: a.s + Number(r.sales), o: a.o + Number(r.orders) }), { s: 0, o: 0 });
      $('#rr').innerHTML = `<div class="stats"><div class="card stat">Total sales<b>${peso(sum.s)}</b></div><div class="card stat">Orders<b>${sum.o}</b></div></div>
        ${rows.length ? `<div class="card" style="margin-bottom:1rem">${bars([...rows].reverse().slice(-24))}</div>` : ''}
        ${table(['Period', 'Orders', 'QR Ph', 'Cash', 'Total'], rows.map((r) => `<tr><td>${esc(r.period)}</td><td>${r.orders}</td><td>${peso(r.qrph)}</td><td>${peso(r.cash)}</td><td><b>${peso(r.sales)}</b></td></tr>`))}
        <h3>Top products</h3>${table(['Product', 'Qty sold', 'Sales'], top.map((t) => `<tr><td>${esc(t.name)}</td><td>${t.qty}</td><td>${peso(t.sales)}</td></tr>`))}`;
    }
    $('#rf').addEventListener('submit', (e) => { e.preventDefault(); run().catch((er) => toast(er.message, 'err')); });
    $('#csv').addEventListener('click', (e) => { e.preventDefault(); location.href = '/api/admin/reports/export.csv?' + qs(); });
    await run();
  },
};

function show(t) {
  tab = t;
  $$('#side button').forEach((b) => b.classList.toggle('active', b.dataset.tab === t));
  main.innerHTML = '<p class="muted">Loading…</p>';
  TABS[t]().catch((e) => { main.innerHTML = `<p>${esc(e.message)}</p>`; });
}
const refresh = () => show(tab);

const productFields = () => [
  { name: 'name', label: 'Name', required: true },
  { name: 'category_id', label: 'Category', type: 'select', options: CATS.map((c) => ({ v: c.id, l: c.name })) },
  { name: 'description', label: 'Description', type: 'textarea' },
  { name: 'price', label: 'Price (₱)', type: 'number', step: '0.01', min: 0, required: true },
  { name: 'image_url', label: 'Image URL (https://… or /images/…)' },
  { name: 'available', label: 'Available for sale', type: 'checkbox', default: true },
  { name: 'track_stock', label: 'Track stock for this item', type: 'checkbox' },
  { name: 'stock_qty', label: 'Stock quantity', type: 'number', min: 0, default: 0 },
  { name: 'low_stock_level', label: 'Low-stock alert level', type: 'number', min: 0, default: 5 },
];
const catFields = [{ name: 'name', label: 'Name', required: true }, { name: 'sort_order', label: 'Sort order', type: 'number', default: 0 }];
const userFields = (isNew) => [
  { name: 'name', label: 'Full name', required: true },
  ...(isNew ? [{ name: 'email', label: 'Email', type: 'email', required: true }] : []),
  { name: 'phone', label: 'Phone' },
  { name: 'role', label: 'Role', type: 'select', options: ROLE_OPTS },
  ...(isNew ? [] : [{ name: 'active', label: 'Account active', type: 'checkbox' }]),
  { name: 'password', label: isNew ? 'Password (min 8 chars)' : 'New password (leave blank to keep)', type: 'password', required: isNew, autocomplete: 'new-password' },
];

document.addEventListener('click', async (e) => {
  const t = e.target.closest('[data-tab]'); if (t) return show(t.dataset.tab);
  const b = e.target.closest('[data-act]'); if (!b) return;
  const id = Number(b.dataset.id);
  try {
    switch (b.dataset.act) {
      case 'logout': return logout();
      case 'add-product': formModal('Add product', productFields(), { available: true }, async (d) => { await api('/admin/products', { method: 'POST', body: d }); refresh(); }); break;
      case 'edit-product': formModal('Edit product', productFields(), window.__products.find((p) => p.id === id), async (d) => { await api('/admin/products/' + id, { method: 'PUT', body: d }); refresh(); }); break;
      case 'del-product': if (confirm('Delete this product? Past orders keep their item names.')) { await api('/admin/products/' + id, { method: 'DELETE' }); refresh(); } break;
      case 'add-cat': formModal('Add category', catFields, {}, async (d) => { await api('/admin/categories', { method: 'POST', body: d }); refresh(); }); break;
      case 'edit-cat': formModal('Edit category', catFields, window.__cats.find((c) => c.id === id), async (d) => { await api('/admin/categories/' + id, { method: 'PUT', body: d }); refresh(); }); break;
      case 'del-cat': if (confirm('Delete this category?')) { await api('/admin/categories/' + id, { method: 'DELETE' }); refresh(); } break;
      case 'adjust': formModal('Adjust stock · ' + b.dataset.name, [
        { name: 'change', label: 'Quantity change (+ add, − remove)', type: 'number', required: true },
        { name: 'reason', label: 'Reason', default: 'restock' }], {}, async (d) => { await api(`/admin/inventory/${id}/adjust`, { method: 'POST', body: d }); refresh(); }); break;
      case 'add-user': formModal('Add staff account', userFields(true), { role: 'cashier' }, async (d) => { await api('/admin/users', { method: 'POST', body: d }); refresh(); }); break;
      case 'edit-user': formModal('Edit user', userFields(false), window.__users.find((u) => u.id === id), async (d) => { await api('/admin/users/' + id, { method: 'PUT', body: d }); refresh(); }); break;
      case 'view-order': {
        const { order: o, payments } = await api('/admin/orders/' + id);
        const m = modal(`<h3>${esc(o.order_no)}</h3><p>${payTag(o.payment_status, o.payment_method)} ${statusTag(o.status)}</p>
          <ul>${o.items.map((i) => `<li>${i.qty} × ${esc(i.name)} — ${peso(i.line_total)}</li>`).join('')}</ul><p><b>Total ${peso(o.total)}</b></p>
          <p class="muted">Customer: ${esc(o.customer_name)} · Created ${fmtDT(o.created_at)} · Paid ${fmtDT(o.paid_at)}</p>
          ${payments.length ? `<h4>PayMongo records</h4>${table(['Intent', 'Payment', 'Amount', 'Status'], payments.map((p) => `<tr><td>${esc(p.payment_intent_id)}</td><td>${esc(p.payment_id || '—')}</td><td>${peso(p.amount)}</td><td>${esc(p.status)}</td></tr>`))}` : ''}
          <div class="row end">${o.payment_status === 'unpaid' && o.status !== 'cancelled' ? '<button class="btn danger" id="cx">Cancel order</button>' : ''}
          ${o.payment_status === 'paid' ? `<a class="btn ghost" target="_blank" href="/receipt.html?id=${o.id}&print=1">Receipt</a>` : ''}<button class="btn ghost" data-close>Close</button></div>`);
        const cx = $('#cx', m); if (cx) cx.addEventListener('click', async () => { try { await api(`/admin/orders/${id}/cancel`, { method: 'POST' }); m.close(); refresh(); } catch (er) { toast(er.message, 'err'); } });
        break;
      }
    }
  } catch (err) { toast(err.message, 'err'); }
});

(async () => {
  const u = await requireStaff(['admin']);
  $('#who').textContent = u.name;
  CATS = (await api('/admin/categories')).categories;
  show('dashboard');
})();
