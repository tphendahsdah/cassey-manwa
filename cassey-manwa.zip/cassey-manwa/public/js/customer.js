let MENU = { categories: [], products: [], shop: {} };
let USER = null;
let activeCat = 'all';
let CART = [];
try { CART = JSON.parse(localStorage.getItem('cm_cart') || '[]'); } catch (e) { CART = []; }

const byId = (id) => MENU.products.find((p) => p.id === id);
const saveCart = () => { try { localStorage.setItem('cm_cart', JSON.stringify(CART)); } catch (e) {} };

async function init() {
  try { USER = (await api('/auth/me')).user; } catch (e) {}
  MENU = await api('/menu');
  $('#shopInfo').textContent = [MENU.shop.name, MENU.shop.address, MENU.shop.phone].filter(Boolean).join(' · ');
  CART = CART.filter((c) => byId(c.id));
  renderAccount(); renderChips(); renderGrid(); renderCart();
}

function renderAccount() {
  const staffHome = { admin: '/admin', cashier: '/pos', kitchen: '/kitchen' };
  $('#acct').innerHTML = USER
    ? `${staffHome[USER.role] ? `<a class="link" href="${staffHome[USER.role]}">Staff area</a>` : '<button class="link" data-act="mine">My orders</button>'}<button class="link" data-act="logout">Logout (${esc(USER.name.split(' ')[0])})</button>`
    : '<a class="link" href="/login.html?next=/">Login / Sign up</a>';
}

function renderChips() {
  $('#chips').innerHTML = [{ id: 'all', name: 'All' }, ...MENU.categories]
    .map((c) => `<button class="chip ${String(c.id) === String(activeCat) ? 'active' : ''}" data-act="cat" data-id="${c.id}">${esc(c.name)}</button>`).join('');
}

function renderGrid() {
  const list = MENU.products.filter((p) => activeCat === 'all' || String(p.category_id) === String(activeCat));
  $('#grid').innerHTML = list.map((p) => `
    <article class="product ${p.sold_out ? 'sold' : ''}">
      <div class="img" ${p.image_url ? `style="background-image:url('${esc(encodeURI(p.image_url))}')"` : ''}>${p.image_url ? '' : '☕'}</div>
      <div class="body"><h3>${esc(p.name)}</h3><p>${esc(p.description)}</p>
        <div class="row between"><span class="price">${peso(p.price)}</span>
        ${p.sold_out ? '<span class="tag err">Sold out</span>' : `<button class="btn small" data-act="add" data-id="${p.id}">Add</button>`}</div>
      </div>
    </article>`).join('') || '<p class="muted">No items yet.</p>';
}

const cartTotal = () => CART.reduce((s, c) => s + byId(c.id).price * c.qty, 0);

function renderCart() {
  $('#cartCount').textContent = CART.reduce((s, c) => s + c.qty, 0);
  $('#cartTotal').textContent = peso(cartTotal());
  $('#cartItems').innerHTML = CART.length ? CART.map((c) => {
    const p = byId(c.id);
    return `<div class="line"><div class="grow"><b>${esc(p.name)}</b><div class="muted">${peso(p.price)}</div></div>
      <span class="qty"><button data-act="dec" data-id="${c.id}">−</button><b>${c.qty}</b><button data-act="inc" data-id="${c.id}">+</button></span>
      <b>${peso(p.price * c.qty)}</b></div>`;
  }).join('') : '<p class="muted center" style="margin-top:2rem">Your cart is empty.</p>';
  saveCart();
}

function change(id, d) {
  const line = CART.find((c) => c.id === id);
  if (!line) { if (d > 0) CART.push({ id, qty: 1 }); } else { line.qty += d; if (line.qty <= 0) CART = CART.filter((c) => c.id !== id); else if (line.qty > 50) line.qty = 50; }
  renderCart();
}

function checkout() {
  if (!CART.length) return toast('Your cart is empty', 'err');
  const fields = [
    { name: 'customer_name', label: 'Your name', required: true, default: USER ? USER.name : '', autocomplete: 'name' },
    { name: 'customer_phone', label: 'Mobile number (for order tracking)', required: true, type: 'tel', default: USER && USER.phone ? USER.phone : '', autocomplete: 'tel' },
    { name: 'service_type', label: 'Order type', type: 'select', options: [{ v: 'dine_in', l: 'Dine-in' }, { v: 'takeout', l: 'Takeout' }] },
    { name: 'table_no', label: 'Table number (dine-in, optional)' },
    { name: 'notes', label: 'Notes (optional)', type: 'textarea' },
  ];
  formModal(`Checkout · ${peso(cartTotal())}`, fields, {}, async (d) => {
    const { order } = await api('/orders', { method: 'POST', body: { ...d, items: CART.map((c) => ({ product_id: c.id, qty: c.qty })) } });
    CART = []; renderCart(); $('#drawer').classList.remove('open');
    try { localStorage.setItem('cm_last_phone', d.customer_phone); } catch (e) {}
    openOrder(order.public_token, true);
  }, 'Continue to payment');
}

/* One live window for an order: shows QR Ph while unpaid, then progress until completed. */
function openOrder(token, autoQr) {
  const m = modal('<div id="om"><p class="center muted">Loading…</p></div>');
  let alive = true, sig = '', requesting = false;
  m.addEventListener('click', (e) => { if (e.target === m || e.target.closest('[data-close]')) alive = false; });

  async function requestQr() {
    if (requesting) return; requesting = true;
    try { const d = await api(`/orders/status/${token}/qrph`, { method: 'POST' }); draw(d, true); }
    catch (e) { toast(e.message, 'err'); const b = $('#qrBtn', m); if (b) b.disabled = false; }
    requesting = false;
  }

  function draw({ order: o, qr }, force) {
    const s = JSON.stringify([o.payment_status, o.status, !!qr]);
    if (s === sig && !force) return;
    sig = s;
    const steps = ['new', 'preparing', 'ready', 'completed'];
    const idx = steps.indexOf(o.status);
    let body = `<div class="row between"><h3 style="margin:0">Order ${esc(o.order_no)}</h3>${statusTag(o.status)}</div>
      <ul>${o.items.map((i) => `<li>${i.qty} × ${esc(i.name)} — ${peso(i.line_total)}</li>`).join('')}</ul>
      <div class="row between"><b>Total</b><span class="total">${peso(o.total)}</span></div>`;
    if (o.status === 'cancelled') body += '<p class="muted">This order was cancelled.</p>';
    else if (o.payment_status === 'unpaid') {
      body += qr
        ? `<div class="qr"><p><b>Scan with GCash, Maya or any bank app</b><br><span class="muted">Pay exactly ${peso(qr.amount)}. This page updates automatically once payment is received.</span></p>
           <img alt="QR Ph payment code" src="${esc(qr.image)}"><p class="muted">Waiting for payment…</p></div>`
        : `<div class="center"><button class="btn" id="qrBtn" data-act="genqr">Pay with QR Ph</button></div>`;
    } else {
      body += `<div class="steps">${steps.map((st, i) => `<div class="step ${i < idx || o.status === 'completed' ? 'done' : i === idx ? 'now' : ''}">${esc(STATUS_LABEL[st])}</div>`).join('')}</div>
        <p class="center">${o.status === 'ready' ? '✅ Your order is ready — please pick it up!' : '✔ Payment received. We are preparing your order.'}</p>
        <div class="row end"><a class="btn ghost" target="_blank" rel="noopener" href="/receipt.html?token=${encodeURIComponent(token)}&print=1">Print / save receipt</a></div>`;
    }
    body += '<div class="row end"><button class="btn ghost" data-close>Close</button></div>';
    $('#om', m).innerHTML = body;
    const g = $('[data-act="genqr"]', m);
    if (g) g.addEventListener('click', () => { g.disabled = true; requestQr(); });
    if (!qr && o.payment_status === 'unpaid' && o.status === 'pending_payment' && autoQr && !requesting) { autoQr = false; requestQr(); }
  }

  async function tick(refresh) {
    if (!alive || !document.body.contains(m)) return;
    try {
      const d = refresh ? await api(`/orders/status/${token}/refresh`, { method: 'POST' }) : await api('/orders/status/' + token);
      draw(d);
      const o = d.order;
      if (o.status !== 'completed' && o.status !== 'cancelled') setTimeout(() => tick(o.payment_status === 'unpaid'), o.payment_status === 'unpaid' ? 4000 : 8000);
    } catch (e) { setTimeout(() => tick(refresh), 8000); }
  }
  tick(false);
}

function trackOrder() {
  let phone = '';
  try { phone = localStorage.getItem('cm_last_phone') || ''; } catch (e) {}
  formModal('Track your order', [
    { name: 'order_no', label: 'Order number (e.g. CM261106-1234)', required: true },
    { name: 'phone', label: 'Mobile number used when ordering', required: true, type: 'tel', default: phone },
  ], {}, async (d) => { const r = await api('/orders/track', { method: 'POST', body: d }); openOrder(r.public_token, false); }, 'Track');
}

async function myOrders() {
  const { orders } = await api('/orders/mine');
  const m = modal(`<h3>My orders</h3>${orders.length ? `<table><tbody>${orders.map((o) => `<tr><td>${esc(o.order_no)}<br><span class="muted">${fmtDT(o.created_at)}</span></td><td>${peso(o.total)}</td><td>${statusTag(o.status)}</td><td><button class="btn small ghost" data-act="open" data-t="${o.public_token}">View</button></td></tr>`).join('')}</tbody></table>` : '<p class="muted">No orders yet.</p>'}
    <div class="row end"><button class="btn ghost" data-close>Close</button></div>`);
  m.addEventListener('click', (e) => { const b = e.target.closest('[data-act="open"]'); if (b) { m.close(); openOrder(b.dataset.t, true); } });
}

document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]');
  if (!b) return;
  const id = Number(b.dataset.id);
  switch (b.dataset.act) {
    case 'cat': activeCat = b.dataset.id; renderChips(); renderGrid(); break;
    case 'add': change(id, 1); toast('Added to cart', 'ok'); break;
    case 'inc': change(id, 1); break;
    case 'dec': change(id, -1); break;
    case 'cart': $('#drawer').classList.toggle('open'); break;
    case 'checkout': checkout(); break;
    case 'track': trackOrder(); break;
    case 'mine': myOrders().catch((er) => toast(er.message, 'err')); break;
    case 'logout': logout(); break;
  }
});

init().catch((e) => toast(e.message, 'err'));
