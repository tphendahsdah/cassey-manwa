let MENU = { categories: [], products: [] };
let CART = [];
let activeCat = 'all', svc = 'dine_in', busy = false;
const byId = (id) => MENU.products.find((p) => p.id === id);
const total = () => CART.reduce((s, c) => s + byId(c.id).price * c.qty, 0);

async function init() {
  const user = await requireStaff(['cashier', 'admin']);
  $('#who').textContent = user.name;
  await loadMenu();
}
async function loadMenu() {
  MENU = await api('/menu');
  renderChips(); renderGrid(); renderCart();
}

function renderChips() {
  $('#chips').innerHTML = [{ id: 'all', name: 'All' }, ...MENU.categories]
    .map((c) => `<button class="chip ${String(c.id) === String(activeCat) ? 'active' : ''}" data-act="cat" data-id="${c.id}">${esc(c.name)}</button>`).join('');
}
function renderGrid() {
  const q = $('#search').value.trim().toLowerCase();
  const list = MENU.products.filter((p) => (activeCat === 'all' || String(p.category_id) === String(activeCat)) && (!q || p.name.toLowerCase().includes(q)));
  $('#grid').innerHTML = list.map((p) => `
    <article class="product ${p.sold_out ? 'sold' : ''}" ${p.sold_out ? '' : `data-act="add" data-id="${p.id}"`}>
      <div class="img" ${p.image_url ? `style="background-image:url('${esc(encodeURI(p.image_url))}')"` : ''}>${p.image_url ? '' : '☕'}</div>
      <div class="body"><b>${esc(p.name)}</b><div class="row between"><span class="price">${peso(p.price)}</span>${p.sold_out ? '<span class="tag err">Out</span>' : p.track_stock ? `<span class="tag">${p.stock_qty} left</span>` : ''}</div></div>
    </article>`).join('');
}
function renderCart() {
  $('#total').textContent = peso(total());
  $('#cartItems').innerHTML = CART.length ? CART.map((c) => {
    const p = byId(c.id);
    return `<div class="line"><div class="grow"><b>${esc(p.name)}</b><div class="muted">${peso(p.price)}</div></div>
      <span class="qty"><button data-act="dec" data-id="${c.id}">−</button><b>${c.qty}</b><button data-act="inc" data-id="${c.id}">+</button></span>
      <b>${peso(p.price * c.qty)}</b><button class="btn ghost small" data-act="rm" data-id="${c.id}">✕</button></div>`;
  }).join('') : '<p class="muted center" style="margin-top:2rem">Tap items to add them.</p>';
}
function change(id, d) {
  const l = CART.find((c) => c.id === id);
  if (!l) { if (d > 0) CART.push({ id, qty: 1 }); } else { l.qty += d; if (l.qty <= 0) CART = CART.filter((c) => c.id !== id); }
  renderCart();
}

async function createOrder() {
  if (!CART.length) { toast('Cart is empty', 'err'); return null; }
  const { order } = await api('/pos/orders', { method: 'POST', body: {
    items: CART.map((c) => ({ product_id: c.id, qty: c.qty })), service_type: svc,
    table_no: $('#tbl').value, customer_name: $('#cname').value,
  } });
  return order;
}
function resetSale() { CART = []; $('#cname').value = ''; $('#tbl').value = ''; renderCart(); loadMenu(); }
function printReceipt(id) { window.open(`/receipt.html?id=${id}&print=1`, '_blank', 'width=420,height=700'); }

async function payQr() {
  if (busy) return; busy = true;
  let order;
  try {
    order = await createOrder(); if (!order) { busy = false; return; }
    const { qr } = await api(`/pos/orders/${order.id}/qrph`, { method: 'POST' });
    showQr(order, qr);
  } catch (e) { toast(e.message, 'err'); if (order) api(`/pos/orders/${order.id}/cancel`, { method: 'POST' }).catch(() => {}); }
  busy = false;
}
function showQr(order, qr) {
  const m = modal(`<div class="qr"><h3>Order ${esc(order.order_no)}</h3><p>Customer scans with GCash, Maya or any bank app</p>
    <img alt="QR Ph" src="${esc(qr.image)}"><div class="total">${peso(qr.amount)}</div><p class="muted" id="qs">Waiting for payment…</p>
    <div class="row end"><button class="btn danger" data-act-local="cancel">Cancel order</button><button class="btn ghost" data-close>Keep open later</button></div></div>`);
  let alive = true;
  m.addEventListener('click', (e) => { if (e.target === m || e.target.closest('[data-close]')) alive = false; });
  $('[data-act-local="cancel"]', m).addEventListener('click', async () => {
    try { await api(`/pos/orders/${order.id}/cancel`, { method: 'POST' }); alive = false; m.close(); resetSale(); toast('Order cancelled'); } catch (e) { toast(e.message, 'err'); }
  });
  (async function poll() {
    while (alive && document.body.contains(m)) {
      await new Promise((r) => setTimeout(r, 3000));
      if (!alive) break;
      try {
        const { order: o } = await api(`/pos/orders/${order.id}/refresh`, { method: 'POST' });
        if (o.payment_status === 'paid') {
          alive = false;
          m.querySelector('.modal').innerHTML = `<div class="center"><h2 style="color:var(--ok)">✔ Payment received</h2><p>${esc(o.order_no)} · ${peso(o.total)}</p>
            <div class="row end"><button class="btn" id="pr">Print receipt</button><button class="btn ghost" data-close>Done</button></div></div>`;
          $('#pr', m).addEventListener('click', () => printReceipt(o.id));
          printReceipt(o.id); resetSale(); return;
        }
        if (o.status === 'cancelled') { alive = false; m.close(); return; }
      } catch (e) { /* keep polling */ }
    }
  })();
}

async function payCash() {
  if (busy) return; busy = true;
  try {
    if (!CART.length) { toast('Cart is empty', 'err'); busy = false; return; }
    const due = total();
    formModal(`Cash payment · ${peso(due)}`, [{ name: 'tendered', label: 'Cash received (₱)', type: 'number', step: '0.01', min: due, required: true, default: due }], {}, async (d) => {
      const order = await createOrder();
      try {
        const r = await api(`/pos/orders/${order.id}/cash`, { method: 'POST', body: { tendered: d.tendered } });
        toast(`Paid. Change: ${peso(r.order.cash_change)}`, 'ok');
        printReceipt(order.id); resetSale();
      } catch (e) { await api(`/pos/orders/${order.id}/cancel`, { method: 'POST' }).catch(() => {}); throw e; }
    }, 'Confirm payment');
  } finally { busy = false; }
}

async function loadOrders() {
  const { orders } = await api('/pos/orders');
  $('#ordersBody').innerHTML = orders.map((o) => `<tr><td><b>${esc(o.order_no)}</b><br><span class="tag">${o.source === 'pos' ? 'Walk-in' : 'Online'}</span></td>
    <td>${fmtDT(o.created_at)}</td><td>${o.service_type === 'dine_in' ? 'Dine-in' : 'Takeout'}${o.table_no ? ' · ' + esc(o.table_no) : ''}</td><td>${esc(o.customer_name)}</td>
    <td>${peso(o.total)}</td><td>${payTag(o.payment_status, o.payment_method)}</td><td>${statusTag(o.status)}</td>
    <td>${o.payment_status === 'paid' ? `<button class="btn small ghost" data-act="reprint" data-id="${o.id}">Receipt</button>` : o.status === 'pending_payment' ? `<button class="btn small" data-act="resume" data-id="${o.id}">Collect</button> <button class="btn small danger" data-act="cancel-order" data-id="${o.id}">Cancel</button>` : ''}</td></tr>`).join('')
    || '<tr><td colspan="8" class="muted center">No orders today.</td></tr>';
}

function view(v) {
  $('#sellView').hidden = v !== 'sell'; $('#ordersView').hidden = v !== 'orders';
  $$('[data-view]').forEach((b) => b.classList.toggle('active', b.dataset.view === v));
  if (v === 'orders') loadOrders().catch((e) => toast(e.message, 'err'));
}

document.addEventListener('click', async (e) => {
  const v = e.target.closest('[data-view]'); if (v) return view(v.dataset.view);
  const s = e.target.closest('[data-svc]'); if (s) { svc = s.dataset.svc; $$('[data-svc]').forEach((x) => x.classList.toggle('active', x === s)); return; }
  const b = e.target.closest('[data-act]'); if (!b) return;
  const id = Number(b.dataset.id);
  try {
    switch (b.dataset.act) {
      case 'cat': activeCat = b.dataset.id; renderChips(); renderGrid(); break;
      case 'add': case 'inc': change(id, 1); break;
      case 'dec': change(id, -1); break;
      case 'rm': CART = CART.filter((c) => c.id !== id); renderCart(); break;
      case 'clear': CART = []; renderCart(); break;
      case 'pay-qr': await payQr(); break;
      case 'pay-cash': await payCash(); break;
      case 'reload': await loadOrders(); break;
      case 'reprint': printReceipt(id); break;
      case 'cancel-order': await api(`/pos/orders/${id}/cancel`, { method: 'POST' }); toast('Cancelled'); loadOrders(); break;
      case 'resume': { const { order } = await api(`/pos/orders/${id}`).then((r) => r); const { qr } = await api(`/pos/orders/${id}/qrph`, { method: 'POST' }); showQr(order, qr); break; }
      case 'logout': logout(); break;
    }
  } catch (err) { toast(err.message, 'err'); }
});
$('#search').addEventListener('input', renderGrid);
init().catch((e) => toast(e.message, 'err'));
