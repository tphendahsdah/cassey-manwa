let mode = 'login';
const HOME = { admin: '/admin', cashier: '/pos', kitchen: '/kitchen', customer: '/' };

$$('[data-mode]').forEach((b) => b.addEventListener('click', () => {
  mode = b.dataset.mode;
  $$('[data-mode]').forEach((x) => x.classList.toggle('active', x === b));
  $('#regOnly').hidden = mode !== 'register';
  $('#go').textContent = mode === 'register' ? 'Create account' : 'Login';
}));

$('#f').addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = e.target.elements;
  const body = { email: f.email.value, password: f.password.value };
  if (mode === 'register') { body.name = f.name.value; body.phone = f.phone.value; }
  $('#go').disabled = true;
  try {
    const { user } = await api(mode === 'register' ? '/auth/register' : '/auth/login', { method: 'POST', body });
    const next = new URLSearchParams(location.search).get('next');
    // only allow same-site relative redirects
    location.href = next && next.startsWith('/') && !next.startsWith('//') && user.role !== 'customer' ? next : HOME[user.role] || '/';
  } catch (err) { toast(err.message, 'err'); $('#go').disabled = false; }
});
