/* Shared helpers (no inline scripts anywhere: the CSP blocks them) */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
const peso = (n) => '₱' + Number(n || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmtDT = (d) => (d ? new Date(d).toLocaleString('en-PH', { timeZone: 'Asia/Manila', dateStyle: 'medium', timeStyle: 'short' }) : '—');

async function api(path, opts = {}) {
  const res = await fetch('/api' + path, {
    method: opts.method || 'GET',
    headers: opts.body ? { 'Content-Type': 'application/json' } : {},
    body: opts.body ? JSON.stringify(opts.body) : undefined,
    credentials: 'same-origin',
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || 'Request failed');
    err.status = res.status;
    throw err;
  }
  return data;
}

function toast(msg, type = '') {
  let box = $('#toasts');
  if (!box) { box = document.createElement('div'); box.id = 'toasts'; document.body.appendChild(box); }
  const t = document.createElement('div');
  t.className = 'toast ' + type;
  t.textContent = msg;
  box.appendChild(t);
  setTimeout(() => t.remove(), 3800);
}

function modal(html) {
  const w = document.createElement('div');
  w.className = 'modal-bg';
  w.innerHTML = `<div class="modal">${html}</div>`;
  document.body.appendChild(w);
  w.close = () => w.remove();
  w.addEventListener('click', (e) => { if (e.target === w || e.target.closest('[data-close]')) w.remove(); });
  return w;
}

function fieldHtml(f, val) {
  const v = val ?? f.default ?? '';
  const req = f.required ? 'required' : '';
  let input;
  if (f.type === 'select') input = `<select name="${f.name}" ${req}>${f.options.map((o) => `<option value="${esc(o.v)}" ${String(o.v) === String(v) ? 'selected' : ''}>${esc(o.l)}</option>`).join('')}</select>`;
  else if (f.type === 'checkbox') return `<label class="check"><input type="checkbox" name="${f.name}" ${v ? 'checked' : ''}> ${esc(f.label)}</label>`;
  else if (f.type === 'textarea') input = `<textarea name="${f.name}" rows="3" ${req}>${esc(v)}</textarea>`;
  else input = `<input name="${f.name}" type="${f.type || 'text'}" value="${esc(v)}" ${req} ${f.step ? `step="${f.step}"` : ''} ${f.min != null ? `min="${f.min}"` : ''} ${f.autocomplete ? `autocomplete="${f.autocomplete}"` : ''}>`;
  return `<label>${esc(f.label)}</label>${input}`;
}

function formModal(title, fields, values, onSubmit, submitLabel = 'Save') {
  const m = modal(`<h3>${esc(title)}</h3><form>${fields.map((f) => fieldHtml(f, values[f.name])).join('')}
    <div class="row end"><button type="button" class="btn ghost" data-close>Cancel</button><button class="btn">${esc(submitLabel)}</button></div></form>`);
  m.querySelector('form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = {};
    for (const f of fields) {
      const el = e.target.elements[f.name];
      data[f.name] = f.type === 'checkbox' ? el.checked : f.type === 'number' ? (el.value === '' ? null : Number(el.value)) : el.value;
    }
    const btn = e.target.querySelector('.btn:not(.ghost)');
    btn.disabled = true;
    try { await onSubmit(data); m.close(); } catch (err) { toast(err.message, 'err'); btn.disabled = false; }
  });
  return m;
}

/** Gate for staff pages. Redirects to login when the role isn't allowed. */
async function requireStaff(roles) {
  try {
    const { user } = await api('/auth/me');
    if (user && roles.includes(user.role)) return user;
  } catch (e) { /* fall through */ }
  location.href = '/login.html?next=' + encodeURIComponent(location.pathname);
  return new Promise(() => {});
}

async function logout() {
  await api('/auth/logout', { method: 'POST' }).catch(() => {});
  location.href = '/login.html';
}

const STATUS_LABEL = { pending_payment: 'Awaiting payment', new: 'Received', preparing: 'Preparing', ready: 'Ready', completed: 'Completed', cancelled: 'Cancelled' };
const statusTag = (s) => `<span class="tag ${s === 'completed' || s === 'ready' ? 'ok' : s === 'cancelled' ? 'err' : s === 'pending_payment' ? 'warn' : ''}">${esc(STATUS_LABEL[s] || s)}</span>`;
const payTag = (p, m) => `<span class="tag ${p === 'paid' ? 'ok' : 'warn'}">${p === 'paid' ? 'Paid' + (m ? ' · ' + (m === 'qrph' ? 'QR Ph' : 'Cash') : '') : 'Unpaid'}</span>`;
