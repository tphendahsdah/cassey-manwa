(async () => {
  const q = new URLSearchParams(location.search);
  try {
    const d = q.get('token') ? await api('/receipt/' + encodeURIComponent(q.get('token'))) : await api('/pos/orders/' + encodeURIComponent(q.get('id')));
    const o = d.order, s = d.shop || {};
    if (o.payment_status !== 'paid') { $('#rc').innerHTML = '<p class="c">This order has not been paid yet.</p>'; return; }
    $('#rc').innerHTML = `
      <h2>${esc(s.name || 'CASSEY MANWA')}</h2>
      <div class="c">${esc(s.address || '')}<br>${esc(s.phone || '')}</div><hr>
      <div>Order: <b>${esc(o.order_no)}</b></div>
      <div>Date: ${fmtDT(o.paid_at)}</div>
      <div>${o.service_type === 'dine_in' ? 'Dine-in' : 'Takeout'}${o.table_no ? ' · Table ' + esc(o.table_no) : ''}</div>
      <div>Customer: ${esc(o.customer_name)}</div><hr>
      ${o.items.map((i) => `<div>${esc(i.name)}</div><div class="t"><span>${i.qty} x ${peso(i.price)}</span><span>${peso(i.line_total)}</span></div>`).join('')}
      <hr><div class="t"><b>TOTAL</b><b>${peso(o.total)}</b></div>
      <div class="t"><span>Payment</span><span>${o.payment_method === 'qrph' ? 'QR Ph (GCash/Maya/Bank)' : 'Cash'}</span></div>
      ${o.payment_method === 'cash' ? `<div class="t"><span>Cash</span><span>${peso(o.cash_tendered)}</span></div><div class="t"><span>Change</span><span>${peso(o.cash_change)}</span></div>` : ''}
      <hr><div class="c">Thank you! Please come again ☕</div>`;
    if (q.get('print') === '1') setTimeout(() => window.print(), 400);
  } catch (e) { $('#rc').innerHTML = `<p class="c">${esc(e.message)}</p>`; }
})();
$('#pr').addEventListener('click', () => window.print());
