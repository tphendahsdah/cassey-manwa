require('dotenv').config();
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');

const { webhookHandler } = require('./src/services/paymongo');

const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      imgSrc: ["'self'", 'data:', 'https:'],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"],
      upgradeInsecureRequests: process.env.NODE_ENV === 'production' ? [] : null,
    },
  },
}));

// Webhook needs the RAW body for signature verification, so it is registered BEFORE express.json()
app.post('/api/webhooks/paymongo', express.raw({ type: '*/*', limit: '1mb' }), webhookHandler);

app.use(express.json({ limit: '100kb' }));
app.use(cookieParser());

app.use('/api/auth/login', rateLimit({ windowMs: 15 * 60 * 1000, max: 15, standardHeaders: true, message: { error: 'Too many attempts. Try again later.' } }));
app.use('/api/auth/register', rateLimit({ windowMs: 60 * 60 * 1000, max: 20, message: { error: 'Too many sign-ups. Try again later.' } }));
app.use('/api/orders/track', rateLimit({ windowMs: 15 * 60 * 1000, max: 30, message: { error: 'Too many lookups. Try again later.' } }));
app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, max: 4000, standardHeaders: true }));

// Light CSRF defence for cookie auth: state-changing API calls must come from our own origin
app.use('/api', (req, res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const origin = req.get('Origin');
  if (origin && new URL(origin).host !== req.get('Host')) return res.status(403).json({ error: 'Bad origin' });
  next();
});

app.use('/api/admin', require('./src/routes/admin'));
app.use('/api', require('./src/routes/staff'));
app.use('/api', require('./src/routes/public'));
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'], maxAge: '1h' }));

app.use((err, req, res, next) => {
  const status = err.status || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({ error: status >= 500 && !err.status ? 'Server error' : err.message });
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`CASSEY MANWA running on port ${port}`));
module.exports = app;
