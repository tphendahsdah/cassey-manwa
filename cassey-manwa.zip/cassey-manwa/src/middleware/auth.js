const jwt = require('jsonwebtoken');
const pool = require('../db');

const SECRET = process.env.JWT_SECRET;
if (!SECRET || SECRET.length < 32) {
  throw new Error('JWT_SECRET must be set in .env and be at least 32 characters');
}

function setSession(res, user) {
  const token = jwt.sign({ id: user.id }, SECRET, { expiresIn: '12h' });
  res.cookie('token', token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 12 * 3600 * 1000,
  });
}

async function loadUser(req) {
  const t = req.cookies && req.cookies.token;
  if (!t) return null;
  const { id } = jwt.verify(t, SECRET);
  const [[row]] = await pool.query('SELECT id,name,email,phone,role,active FROM users WHERE id=?', [id]);
  return row && row.active ? row : null;
}

async function optionalAuth(req, res, next) {
  try { req.user = await loadUser(req); } catch (e) { req.user = null; }
  next();
}

function requireRole(...roles) {
  return async (req, res, next) => {
    let user;
    try { user = await loadUser(req); } catch (e) { user = null; }
    if (!user) return res.status(401).json({ error: 'Please log in' });
    if (roles.length && !roles.includes(user.role)) return res.status(403).json({ error: 'Not allowed' });
    req.user = user;
    next();
  };
}

module.exports = { setSession, optionalAuth, requireRole };
