const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  decimalNumbers: true,
  timezone: '+08:00',
  charset: 'utf8mb4',
});

// Philippine time for NOW(), DATE() grouping in reports, etc.
pool.pool.on('connection', (c) => c.query("SET time_zone='+08:00'"));

module.exports = pool;
