class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const money = (n) => Math.round(Number(n) * 100) / 100;
const str = (v, max, required = false, label = 'Field') => {
  const s = (v == null ? '' : String(v)).trim().slice(0, max);
  if (required && !s) throw new HttpError(400, `${label} is required`);
  return s;
};
module.exports = { HttpError, wrap, money, str };
