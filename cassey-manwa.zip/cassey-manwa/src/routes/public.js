const express = require('express');
const bcrypt = require('bcryptjs');
const pool = require('../db');
const { wrap, HttpError, str } = require('../util');
const { setSession, optionalAuth, requireRole } = require('../middleware/auth');
const { createOrder, loadOrder, publicOrder } = require('../services/orders');
const { createQrPh, refreshOrderPayments } = require('../services/paymongo');

const r = express.Router();
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_RE = /^[0-9+\-\s()]{7,20}$/;

/* ---------- Auth ---------- */
r.post('/auth/register', wrap(async (req, res) => {
  const name = str(req.body.name, 120, true, 'Name');
  const email = str(req.body.email, 190, true, 'Email').toLowerCase();
  const phone = str(req.body.phone, 30);
  const password = String(req.body.password || '');
  if (!EMAIL_RE.test(email)) throw new HttpError(400, 'Invalid email');
  if (phone && !PHONE_RE.test(phone)) throw new HttpError(400, 'Invalid phone number');
  if (password.length < 8) throw new HttpError(400, 'Password must be at least 8 characters');
  const [[dup]] = await pool.query('SELECT id FROM users WHERE email=?', [email]);
  if (dup) throw new HttpError(409, 'Email is already registered');
  const hash = await bcrypt.hash(password, 12);
  const [ins] = await pool.query("INSERT INTO users (name,email,phone,password_hash,role) VALUES (?,?,?,?, 'customer')", [name, email, phone || null, hash]);
  setSession(res, { id: ins.insertId });
  res.json({ user: { id: ins.insertId, name, email, phone, role: 'customer' } });
}));

r.post('/auth/login', wrap(async (req, res) => {
  const email = str(req.body.email, 190).toLowerCase();
  const [[u]] = await pool.query('SELECT * FROM users WHERE email=?', [email]);
  // Compare even when user missing to keep timing similar
  const ok = await bcrypt.compare(String(req.body.password || ''), u ? u.password_hash : '$2a$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvalidinva');
  if (!u || !ok || !u.active) throw new HttpError(401, 'Wrong email or password');
  setSession(res, u);
  res.json({ user: { id: u.id, name: u.name, email: u.email, phone: u.phone, role: u.role } });
}));

r.post('/auth/logout', (req, res) => { res.clearCookie('token'); res.json({ ok: true }); });

r.get('/auth/me', optionalAuth, (req, res) => {
  const u = req.user;
  res.json({ user: u ? { id: u.id, name: u.name, email: u.email, phone: u.phone, role: u.role } : null });
});

/* ---------- Menu ---------- */
r.get('/menu', wrap(async (req, res) => {
  const [categories] = await pool.query('SELECT id,name FROM categories ORDER BY sort_order,name');
  const [products] = await pool.query(
    'SELECT id,category_id,name,description,price,image_url,available,track_stock,stock_qty FROM products ORDER BY name'
  );
  res.json({
    shop: { name: process.env.SHOP_NAME || 'CASSEY MANWA', address: process.env.SHOP_ADDRESS || '', phone: process.env.SHOP_PHONE || '' },
    categories,
    products: products.map((p) => ({ ...p, sold_out: !p.available || (p.track_stock && p.stock_qty <= 0) })),
  });
}));

/* ---------- Online orders ---------- */
r.post('/orders', optionalAuth, wrap(async (req, res) => {
  const b = req.body;
  const phone = str(b.customer_phone, 30, true, 'Phone number');
  if (!PHONE_RE.test(phone)) throw new HttpError(400, 'Invalid phone number');
  const o = await createOrder({
    items: b.items, source: 'online', service_type: b.service_type, table_no: b.table_no,
    customer_name: str(b.customer_name, 120, true, 'Name'), customer_phone: phone, notes: b.notes,
    user_id: req.user ? req.user.id : null,
  });
  res.json({ order: { order_no: o.order_no, public_token: o.public_token, total: o.total } });
}));

r.get('/orders/mine', requireRole('customer'), wrap(async (req, res) => {
  const [rows] = await pool.query('SELECT order_no,public_token,status,payment_status,total,created_at FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 30', [req.user.id]);
  res.json({ orders: rows });
}));

// Track by order number + phone (stops people from guessing other customers' orders)
r.post('/orders/track', wrap(async (req, res) => {
  const o = await loadOrder('order_no=? AND customer_phone=?', [str(req.body.order_no, 30).toUpperCase(), str(req.body.phone, 30)]);
  if (!o) throw new HttpError(404, 'Order not found. Check the order number and phone number.');
  res.json({ public_token: o.public_token });
}));

async function statusPayload(token, { withQr = false } = {}) {
  const o = await loadOrder('public_token=?', [token]);
  if (!o) throw new HttpError(404, 'Order not found');
  let qr = null;
  if (o.payment_status === 'unpaid' && o.status === 'pending_payment') {
    const [[p]] = await pool.query("SELECT qr_image,amount FROM payments WHERE order_id=? AND status='pending' AND created_at > (NOW() - INTERVAL 25 MINUTE) ORDER BY id DESC LIMIT 1", [o.id]);
    if (p) qr = { image: p.qr_image, amount: p.amount };
  }
  return { order: publicOrder(o), qr };
}

r.get('/orders/status/:token', wrap(async (req, res) => res.json(await statusPayload(req.params.token))));

r.post('/orders/status/:token/qrph', wrap(async (req, res) => {
  const o = await loadOrder('public_token=?', [req.params.token]);
  if (!o) throw new HttpError(404, 'Order not found');
  await createQrPh(o);
  res.json(await statusPayload(req.params.token));
}));

// Polling endpoint: asks PayMongo directly (real verification) in case the webhook is delayed
r.post('/orders/status/:token/refresh', wrap(async (req, res) => {
  const o = await loadOrder('public_token=?', [req.params.token]);
  if (!o) throw new HttpError(404, 'Order not found');
  if (o.payment_status === 'unpaid') {
    try { await refreshOrderPayments(o.id); } catch (e) { console.error('refresh failed:', e.message); }
  }
  res.json(await statusPayload(req.params.token));
}));

r.get('/receipt/:token', wrap(async (req, res) => {
  const o = await loadOrder('public_token=? AND payment_status="paid"', [req.params.token]);
  if (!o) throw new HttpError(404, 'Receipt not available (order not paid)');
  res.json({ shop: { name: process.env.SHOP_NAME, address: process.env.SHOP_ADDRESS, phone: process.env.SHOP_PHONE }, order: publicOrder(o) });
}));

module.exports = r;
