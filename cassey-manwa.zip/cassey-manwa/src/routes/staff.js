const express = require('express');
const pool = require('../db');
const { wrap, HttpError, str, money } = require('../util');
const { requireRole } = require('../middleware/auth');
const { createOrder, markPaid, loadOrder, publicOrder } = require('../services/orders');
const { createQrPh, refreshOrderPayments } = require('../services/paymongo');

const r = express.Router();

/* ================= POS (cashier + admin) ================= */
const pos = express.Router();
pos.use(requireRole('cashier', 'admin'));

pos.get('/orders', wrap(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT id,order_no,source,service_type,table_no,customer_name,total,status,payment_status,payment_method,created_at
     FROM orders WHERE DATE(created_at)=CURDATE() ORDER BY id DESC LIMIT 200`);
  res.json({ orders: rows });
}));

pos.post('/orders', wrap(async (req, res) => {
  const b = req.body;
  const o = await createOrder({
    items: b.items, source: 'pos', service_type: b.service_type, table_no: b.table_no,
    customer_name: str(b.customer_name, 120) || 'Walk-in', notes: b.notes, cashier_id: req.user.id,
  });
  res.json({ order: o });
}));

pos.get('/orders/:id', wrap(async (req, res) => {
  const o = await loadOrder('id=?', [Number(req.params.id)]);
  if (!o) throw new HttpError(404, 'Order not found');
  res.json({ shop: { name: process.env.SHOP_NAME, address: process.env.SHOP_ADDRESS, phone: process.env.SHOP_PHONE }, order: publicOrder(o) });
}));

pos.post('/orders/:id/qrph', wrap(async (req, res) => {
  const o = await loadOrder('id=?', [Number(req.params.id)]);
  if (!o) throw new HttpError(404, 'Order not found');
  const qr = await createQrPh(o);
  res.json({ qr, order: publicOrder(o) });
}));

pos.post('/orders/:id/refresh', wrap(async (req, res) => {
  const id = Number(req.params.id);
  let o = await loadOrder('id=?', [id]);
  if (!o) throw new HttpError(404, 'Order not found');
  if (o.payment_status === 'unpaid') {
    try { await refreshOrderPayments(id); } catch (e) { console.error('refresh failed:', e.message); }
    o = await loadOrder('id=?', [id]);
  }
  res.json({ order: publicOrder(o) });
}));

// Cash is collected by the cashier in person; the cashier confirms the tendered amount.
pos.post('/orders/:id/cash', wrap(async (req, res) => {
  const o = await loadOrder('id=?', [Number(req.params.id)]);
  if (!o) throw new HttpError(404, 'Order not found');
  const tendered = money(req.body.tendered);
  if (!(tendered >= o.total)) throw new HttpError(400, 'Cash received is less than the total');
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const ok = await markPaid(conn, o.id, 'cash', { tendered, change: money(tendered - o.total) });
    if (!ok) throw new HttpError(409, 'Order is already paid or cancelled');
    await conn.commit();
  } catch (e) { await conn.rollback(); throw e; } finally { conn.release(); }
  res.json({ order: publicOrder(await loadOrder('id=?', [o.id])) });
}));

pos.post('/orders/:id/cancel', wrap(async (req, res) => {
  const [u] = await pool.query("UPDATE orders SET status='cancelled' WHERE id=? AND payment_status='unpaid'", [Number(req.params.id)]);
  if (!u.affectedRows) throw new HttpError(409, 'Only unpaid orders can be cancelled');
  res.json({ ok: true });
}));

r.use('/pos', pos);

/* ================= Kitchen ================= */
const kitchen = express.Router();
kitchen.use(requireRole('kitchen', 'cashier', 'admin'));

kitchen.get('/orders', wrap(async (req, res) => {
  const [orders] = await pool.query(
    `SELECT id,order_no,service_type,table_no,customer_name,notes,status,paid_at FROM orders
     WHERE payment_status='paid' AND status IN ('new','preparing','ready') ORDER BY paid_at ASC LIMIT 100`);
  if (orders.length) {
    const [items] = await pool.query('SELECT order_id,name,qty FROM order_items WHERE order_id IN (?)', [orders.map((o) => o.id)]);
    for (const o of orders) o.items = items.filter((i) => i.order_id === o.id);
  }
  res.json({ orders });
}));

const NEXT = { new: 'preparing', preparing: 'ready', ready: 'completed' };
kitchen.patch('/orders/:id/status', wrap(async (req, res) => {
  const to = String(req.body.status);
  const from = Object.keys(NEXT).find((k) => NEXT[k] === to);
  if (!from) throw new HttpError(400, 'Invalid status');
  const [u] = await pool.query("UPDATE orders SET status=? WHERE id=? AND status=? AND payment_status='paid'", [to, Number(req.params.id), from]);
  if (!u.affectedRows) throw new HttpError(409, 'Order status changed already. Refresh.');
  res.json({ ok: true });
}));

r.use('/kitchen', kitchen);

module.exports = r;
