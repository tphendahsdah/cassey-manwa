const express = require('express');
const bcrypt = require('bcryptjs');
const pool = require('../db');
const { wrap, HttpError, str, money } = require('../util');
const { requireRole } = require('../middleware/auth');
const { loadOrder, publicOrder } = require('../services/orders');

const r = express.Router();
r.use(requireRole('admin'));

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const ROLES = ['admin', 'cashier', 'kitchen', 'customer'];

const refErr = (e) => {
  if (e.code === 'ER_ROW_IS_REFERENCED_2') throw new HttpError(409, 'Cannot delete: it is still in use');
  if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'That value already exists');
  throw e;
};

/* ---------- Categories ---------- */
r.get('/categories', wrap(async (req, res) => {
  const [rows] = await pool.query('SELECT id,name,sort_order FROM categories ORDER BY sort_order,name');
  res.json({ categories: rows });
}));
r.post('/categories', wrap(async (req, res) => {
  try {
    const [i] = await pool.query('INSERT INTO categories (name,sort_order) VALUES (?,?)', [str(req.body.name, 80, true, 'Name'), Number(req.body.sort_order) || 0]);
    res.json({ id: i.insertId });
  } catch (e) { refErr(e); }
}));
r.put('/categories/:id', wrap(async (req, res) => {
  try {
    await pool.query('UPDATE categories SET name=?, sort_order=? WHERE id=?', [str(req.body.name, 80, true, 'Name'), Number(req.body.sort_order) || 0, Number(req.params.id)]);
    res.json({ ok: true });
  } catch (e) { refErr(e); }
}));
r.delete('/categories/:id', wrap(async (req, res) => {
  try { await pool.query('DELETE FROM categories WHERE id=?', [Number(req.params.id)]); res.json({ ok: true }); } catch (e) { refErr(e); }
}));

/* ---------- Products ---------- */
function productData(b) {
  const price = money(b.price);
  if (!(price >= 0)) throw new HttpError(400, 'Invalid price');
  const img = str(b.image_url, 500);
  if (img && !/^(https?:\/\/|\/)/i.test(img)) throw new HttpError(400, 'Image URL must start with http(s):// or /');
  return {
    category_id: Number(b.category_id),
    name: str(b.name, 120, true, 'Name'),
    description: str(b.description, 500),
    price,
    image_url: img,
    available: b.available ? 1 : 0,
    track_stock: b.track_stock ? 1 : 0,
    stock_qty: Math.max(0, parseInt(b.stock_qty, 10) || 0),
    low_stock_level: Math.max(0, parseInt(b.low_stock_level, 10) || 0),
  };
}
r.get('/products', wrap(async (req, res) => {
  const [rows] = await pool.query('SELECT p.*, c.name AS category FROM products p JOIN categories c ON c.id=p.category_id ORDER BY c.sort_order, p.name');
  res.json({ products: rows });
}));
r.post('/products', wrap(async (req, res) => {
  try { const [i] = await pool.query('INSERT INTO products SET ?', [productData(req.body)]); res.json({ id: i.insertId }); } catch (e) { refErr(e); }
}));
r.put('/products/:id', wrap(async (req, res) => {
  try { await pool.query('UPDATE products SET ? WHERE id=?', [productData(req.body), Number(req.params.id)]); res.json({ ok: true }); } catch (e) { refErr(e); }
}));
r.delete('/products/:id', wrap(async (req, res) => {
  await pool.query('DELETE FROM products WHERE id=?', [Number(req.params.id)]); // order history keeps item names
  res.json({ ok: true });
}));

/* ---------- Inventory ---------- */
r.post('/inventory/:id/adjust', wrap(async (req, res) => {
  const delta = parseInt(req.body.change, 10);
  if (!delta) throw new HttpError(400, 'Enter a non-zero quantity (use negative to remove)');
  const id = Number(req.params.id);
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [u] = await conn.query('UPDATE products SET stock_qty=GREATEST(stock_qty+?,0), track_stock=1 WHERE id=?', [delta, id]);
    if (!u.affectedRows) throw new HttpError(404, 'Product not found');
    await conn.query('INSERT INTO stock_movements (product_id,change_qty,reason,user_id) VALUES (?,?,?,?)', [id, delta, str(req.body.reason, 80) || 'manual adjustment', req.user.id]);
    await conn.commit();
  } catch (e) { await conn.rollback(); throw e; } finally { conn.release(); }
  res.json({ ok: true });
}));
r.get('/inventory/movements', wrap(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT m.created_at, p.name, m.change_qty, m.reason, u.name AS by_user FROM stock_movements m
     JOIN products p ON p.id=m.product_id LEFT JOIN users u ON u.id=m.user_id ORDER BY m.id DESC LIMIT 100`);
  res.json({ movements: rows });
}));

/* ---------- Users ---------- */
r.get('/users', wrap(async (req, res) => {
  const [rows] = await pool.query('SELECT id,name,email,phone,role,active,created_at FROM users ORDER BY role,name');
  res.json({ users: rows });
}));
r.post('/users', wrap(async (req, res) => {
  const email = str(req.body.email, 190, true, 'Email').toLowerCase();
  if (!EMAIL_RE.test(email)) throw new HttpError(400, 'Invalid email');
  if (!ROLES.includes(req.body.role)) throw new HttpError(400, 'Invalid role');
  const pw = String(req.body.password || '');
  if (pw.length < 8) throw new HttpError(400, 'Password must be at least 8 characters');
  try {
    const [i] = await pool.query('INSERT INTO users (name,email,phone,password_hash,role) VALUES (?,?,?,?,?)',
      [str(req.body.name, 120, true, 'Name'), email, str(req.body.phone, 30) || null, await bcrypt.hash(pw, 12), req.body.role]);
    res.json({ id: i.insertId });
  } catch (e) { refErr(e); }
}));
r.put('/users/:id', wrap(async (req, res) => {
  const id = Number(req.params.id);
  if (!ROLES.includes(req.body.role)) throw new HttpError(400, 'Invalid role');
  if (id === req.user.id && (!req.body.active || req.body.role !== 'admin')) throw new HttpError(400, "You can't disable or demote your own account");
  await pool.query('UPDATE users SET name=?, phone=?, role=?, active=? WHERE id=?',
    [str(req.body.name, 120, true, 'Name'), str(req.body.phone, 30) || null, req.body.role, req.body.active ? 1 : 0, id]);
  const pw = String(req.body.password || '');
  if (pw) {
    if (pw.length < 8) throw new HttpError(400, 'Password must be at least 8 characters');
    await pool.query('UPDATE users SET password_hash=? WHERE id=?', [await bcrypt.hash(pw, 12), id]);
  }
  res.json({ ok: true });
}));

/* ---------- Orders ---------- */
r.get('/orders', wrap(async (req, res) => {
  const where = ['1=1'], params = [];
  if (req.query.status) { where.push('status=?'); params.push(String(req.query.status)); }
  if (req.query.payment_status) { where.push('payment_status=?'); params.push(String(req.query.payment_status)); }
  if (req.query.from) { where.push('DATE(created_at)>=?'); params.push(String(req.query.from)); }
  if (req.query.to) { where.push('DATE(created_at)<=?'); params.push(String(req.query.to)); }
  const [rows] = await pool.query(
    `SELECT id,order_no,source,service_type,customer_name,total,status,payment_status,payment_method,created_at,paid_at
     FROM orders WHERE ${where.join(' AND ')} ORDER BY id DESC LIMIT 300`, params);
  res.json({ orders: rows });
}));
r.get('/orders/:id', wrap(async (req, res) => {
  const o = await loadOrder('id=?', [Number(req.params.id)]);
  if (!o) throw new HttpError(404, 'Not found');
  const [pay] = await pool.query('SELECT payment_intent_id,payment_id,amount,status,created_at,paid_at FROM payments WHERE order_id=? ORDER BY id DESC', [o.id]);
  res.json({ order: publicOrder(o), payments: pay });
}));
r.post('/orders/:id/cancel', wrap(async (req, res) => {
  const [u] = await pool.query("UPDATE orders SET status='cancelled' WHERE id=? AND payment_status='unpaid'", [Number(req.params.id)]);
  if (!u.affectedRows) throw new HttpError(409, 'Only unpaid orders can be cancelled (refund paid orders in PayMongo)');
  res.json({ ok: true });
}));

/* ---------- Dashboard & reports ---------- */
const PAID = "payment_status='paid' AND status<>'cancelled'";

r.get('/dashboard', wrap(async (req, res) => {
  const [[t]] = await pool.query(`SELECT COUNT(*) orders, COALESCE(SUM(total),0) sales FROM orders WHERE ${PAID} AND DATE(paid_at)=CURDATE()`);
  const [[pending]] = await pool.query("SELECT COUNT(*) n FROM orders WHERE payment_status='paid' AND status IN ('new','preparing','ready')");
  const [[unpaid]] = await pool.query("SELECT COUNT(*) n FROM orders WHERE status='pending_payment' AND created_at > (NOW() - INTERVAL 1 DAY)");
  const [[low]] = await pool.query('SELECT COUNT(*) n FROM products WHERE track_stock=1 AND stock_qty<=low_stock_level');
  const [days] = await pool.query(
    `SELECT DATE_FORMAT(paid_at,'%Y-%m-%d') period, COUNT(*) orders, SUM(total) sales FROM orders
     WHERE ${PAID} AND paid_at >= (CURDATE() - INTERVAL 6 DAY) GROUP BY period ORDER BY period`);
  res.json({ today: t, in_kitchen: pending.n, awaiting_payment: unpaid.n, low_stock: low.n, last7: days });
}));

const PERIODS = {
  daily: "DATE_FORMAT(paid_at,'%Y-%m-%d')",
  weekly: "DATE_FORMAT(DATE_SUB(DATE(paid_at), INTERVAL WEEKDAY(paid_at) DAY),'%Y-%m-%d')",
  monthly: "DATE_FORMAT(paid_at,'%Y-%m')",
};
function range(q) {
  const params = [];
  let sql = '';
  if (q.from) { sql += ' AND DATE(paid_at)>=?'; params.push(String(q.from)); }
  if (q.to) { sql += ' AND DATE(paid_at)<=?'; params.push(String(q.to)); }
  return { sql, params };
}

r.get('/reports/sales', wrap(async (req, res) => {
  const key = PERIODS[req.query.period] || PERIODS.daily;
  const f = range(req.query);
  if (!f.sql) { f.sql = ' AND paid_at >= (CURDATE() - INTERVAL 90 DAY)'; }
  const [rows] = await pool.query(
    `SELECT ${key} AS period, COUNT(*) orders, SUM(total) sales,
            SUM(CASE WHEN payment_method='qrph' THEN total ELSE 0 END) qrph,
            SUM(CASE WHEN payment_method='cash' THEN total ELSE 0 END) cash
     FROM orders WHERE ${PAID}${f.sql} GROUP BY period ORDER BY period DESC`, f.params);
  const [top] = await pool.query(
    `SELECT oi.name, SUM(oi.qty) qty, SUM(oi.line_total) sales FROM order_items oi JOIN orders o ON o.id=oi.order_id
     WHERE o.payment_status='paid' AND o.status<>'cancelled'${f.sql.replace(/paid_at/g, 'o.paid_at')}
     GROUP BY oi.name ORDER BY qty DESC LIMIT 10`, f.params);
  res.json({ rows, top });
}));

const csvCell = (v) => {
  let s = v == null ? '' : v instanceof Date ? v.toISOString() : String(v);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // block spreadsheet formula injection
  return `"${s.replace(/"/g, '""')}"`;
};
r.get('/reports/export.csv', wrap(async (req, res) => {
  const f = range(req.query);
  const [rows] = await pool.query(
    `SELECT order_no, paid_at, source, service_type, payment_method, customer_name, total FROM orders WHERE ${PAID}${f.sql} ORDER BY paid_at`, f.params);
  const head = ['Order No', 'Paid At', 'Source', 'Service', 'Payment', 'Customer', 'Total'];
  const lines = [head.map(csvCell).join(',')].concat(rows.map((x) => [x.order_no, x.paid_at, x.source, x.service_type, x.payment_method, x.customer_name, x.total].map(csvCell).join(',')));
  res.set('Content-Type', 'text/csv; charset=utf-8');
  res.set('Content-Disposition', 'attachment; filename="sales-report.csv"');
  res.send('﻿' + lines.join('\r\n'));
}));

module.exports = r;
