const crypto = require('crypto');
const pool = require('../db');
const { HttpError } = require('../util');
const { markPaid } = require('./orders');

const BASE = 'https://api.paymongo.com/v1';

function authHeader() {
  const key = process.env.PAYMONGO_SECRET_KEY;
  if (!key) throw new HttpError(503, 'Online payment is not configured yet (missing PayMongo key)');
  return 'Basic ' + Buffer.from(key + ':').toString('base64');
}

async function pm(path, method = 'GET', attributes) {
  const res = await fetch(BASE + path, {
    method,
    headers: { Authorization: authHeader(), 'Content-Type': 'application/json', Accept: 'application/json' },
    body: attributes ? JSON.stringify({ data: { attributes } }) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    console.error('PayMongo error', res.status, JSON.stringify(json));
    throw new HttpError(502, (json.errors && json.errors[0] && json.errors[0].detail) || 'Payment provider error');
  }
  return json.data;
}

/** Find the QR image in the attached intent's next_action (shape: next_action.code.image_url). */
function extractQr(intent) {
  const na = intent.attributes && intent.attributes.next_action;
  return (na && na.code && na.code.image_url) || (na && na.image_url) || null;
}

async function expireOld(orderId) {
  await pool.query("UPDATE payments SET status='expired' WHERE order_id=? AND status='pending' AND created_at < (NOW() - INTERVAL 25 MINUTE)", [orderId]);
}

/** Creates (or reuses a still-fresh) dynamic QR Ph for the exact order total. */
async function createQrPh(order) {
  if (order.payment_status === 'paid') throw new HttpError(409, 'Order is already paid');
  if (order.status !== 'pending_payment') throw new HttpError(409, 'Order is not awaiting payment');

  await expireOld(order.id);
  const [[existing]] = await pool.query(
    "SELECT * FROM payments WHERE order_id=? AND status='pending' AND qr_image IS NOT NULL ORDER BY id DESC LIMIT 1",
    [order.id]
  );
  if (existing) return { image: existing.qr_image, amount: existing.amount };

  const centavos = Math.round(Number(order.total) * 100);
  const intent = await pm('/payment_intents', 'POST', {
    amount: centavos,
    currency: 'PHP',
    payment_method_allowed: ['qrph'],
    capture_type: 'automatic',
    description: `${process.env.SHOP_NAME || 'Coffee Shop'} order ${order.order_no}`,
    statement_descriptor: 'CASSEY MANWA',
    metadata: { order_id: String(order.id), order_no: order.order_no },
  });
  const method = await pm('/payment_methods', 'POST', { type: 'qrph' });
  const attached = await pm(`/payment_intents/${intent.id}/attach`, 'POST', { payment_method: method.id });

  const image = extractQr(attached);
  if (!image) {
    console.error('No QR in PayMongo response', JSON.stringify(attached.attributes && attached.attributes.next_action));
    throw new HttpError(502, 'Could not generate QR Ph code. Please try again.');
  }
  await pool.query('INSERT INTO payments (order_id,payment_intent_id,amount,qr_image,status) VALUES (?,?,?,?,?)', [order.id, intent.id, order.total, image, 'pending']);
  return { image, amount: order.total };
}

/**
 * Confirms with PayMongo (server-to-server) that the intent really succeeded and the amount matches,
 * then atomically marks payment + order paid. Safe to call many times (webhook retries, polling).
 */
async function settleIntent(intentId) {
  const [[p]] = await pool.query('SELECT * FROM payments WHERE payment_intent_id=?', [intentId]);
  if (!p || p.status === 'paid') return p || null;

  const intent = await pm('/payment_intents/' + intentId);
  if (intent.attributes.status !== 'succeeded') return p;
  if (intent.attributes.amount !== Math.round(Number(p.amount) * 100)) {
    console.error('Amount mismatch for intent', intentId);
    throw new HttpError(409, 'Payment amount mismatch');
  }
  const payId = (intent.attributes.payments && intent.attributes.payments[0] && intent.attributes.payments[0].id) || null;

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [r] = await conn.query("UPDATE payments SET status='paid', payment_id=?, paid_at=NOW() WHERE id=? AND status<>'paid'", [payId, p.id]);
    if (r.affectedRows) {
      const ok = await markPaid(conn, p.order_id, 'qrph');
      if (!ok) console.warn(`Payment ${intentId} succeeded but order ${p.order_id} was not payable (already paid/cancelled). Refund manually in PayMongo if needed.`);
    }
    await conn.commit();
  } catch (e) {
    await conn.rollback();
    throw e;
  } finally {
    conn.release();
  }
  return { ...p, status: 'paid' };
}

/** Asks PayMongo about every unpaid intent of an order (used by polling when a webhook is delayed). */
async function refreshOrderPayments(orderId) {
  const [rows] = await pool.query("SELECT payment_intent_id FROM payments WHERE order_id=? AND status IN ('pending','expired') AND created_at > (NOW() - INTERVAL 2 HOUR)", [orderId]);
  for (const r of rows) await settleIntent(r.payment_intent_id);
}

/** Verifies the Paymongo-Signature header: t=<ts>,te=<test sig>,li=<live sig> over `${t}.${rawBody}` */
function verifySignature(rawBody, header) {
  const secret = process.env.PAYMONGO_WEBHOOK_SECRET;
  if (!secret || !header) return false;
  const parts = {};
  header.split(',').forEach((kv) => { const i = kv.indexOf('='); if (i > 0) parts[kv.slice(0, i).trim()] = kv.slice(i + 1).trim(); });
  const sig = process.env.PAYMONGO_LIVE === 'true' ? parts.li : parts.te;
  if (!parts.t || !sig) return false;
  const mac = crypto.createHmac('sha256', secret).update(`${parts.t}.${rawBody}`).digest('hex');
  const a = Buffer.from(mac), b = Buffer.from(sig);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return false;
  return Math.abs(Date.now() / 1000 - Number(parts.t)) < 60 * 60; // reject very old replays
}

async function webhookHandler(req, res) {
  const raw = req.body.toString('utf8');
  if (!verifySignature(raw, req.get('Paymongo-Signature'))) return res.status(401).json({ error: 'Invalid signature' });

  let event;
  try { event = JSON.parse(raw).data; } catch (e) { return res.status(400).json({ error: 'Bad JSON' }); }
  const eventId = event.id, type = event.attributes && event.attributes.type;

  try {
    // Duplicate event? (PayMongo retries) -> acknowledge and skip
    const [ins] = await pool.query('INSERT IGNORE INTO webhook_events (event_id,type) VALUES (?,?)', [eventId, type]);
    if (!ins.affectedRows) return res.json({ ok: true, duplicate: true });

    try {
      const resource = event.attributes.data;
      const intentId = resource && resource.attributes && resource.attributes.payment_intent_id;
      if (type === 'payment.paid' && intentId) {
        await settleIntent(intentId);
      } else if (type === 'payment.failed' && intentId) {
        await pool.query("UPDATE payments SET status='failed' WHERE payment_intent_id=? AND status='pending'", [intentId]);
      }
    } catch (e) {
      await pool.query('DELETE FROM webhook_events WHERE event_id=?', [eventId]); // allow retry
      throw e;
    }
    res.json({ ok: true });
  } catch (e) {
    console.error('Webhook error', e.message);
    res.status(500).json({ error: 'Processing failed' }); // PayMongo will retry
  }
}

module.exports = { createQrPh, settleIntent, refreshOrderPayments, webhookHandler };
