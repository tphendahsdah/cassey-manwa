const crypto = require('crypto');
const pool = require('../db');
const { HttpError, money, str } = require('../util');

function manilaDateStamp() {
  return new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Manila' }).replace(/-/g, '').slice(2);
}

/** Creates an UNPAID order. Prices always come from the database, never from the client. */
async function createOrder(o) {
  const items = Array.isArray(o.items) ? o.items : [];
  if (!items.length || items.length > 50) throw new HttpError(400, 'Cart is empty');

  const qtyBy = new Map();
  for (const it of items) {
    const id = Number(it.product_id), q = Number(it.qty);
    if (!Number.isInteger(id) || !Number.isInteger(q) || q < 1 || q > 50) throw new HttpError(400, 'Invalid cart item');
    qtyBy.set(id, (qtyBy.get(id) || 0) + q);
  }
  if (!['dine_in', 'takeout'].includes(o.service_type)) throw new HttpError(400, 'Choose dine-in or takeout');

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [prods] = await conn.query(
      'SELECT id,name,price,available,track_stock,stock_qty FROM products WHERE id IN (?) FOR UPDATE',
      [[...qtyBy.keys()]]
    );
    if (prods.length !== qtyBy.size) throw new HttpError(400, 'Some items no longer exist');

    let subtotal = 0;
    const lines = [];
    for (const p of prods) {
      const q = qtyBy.get(p.id);
      if (!p.available) throw new HttpError(409, `${p.name} is currently unavailable`);
      if (p.track_stock && p.stock_qty < q) throw new HttpError(409, `Only ${p.stock_qty} left of ${p.name}`);
      const lineTotal = money(p.price * q);
      subtotal += lineTotal;
      lines.push([p, q, lineTotal]);
    }
    subtotal = money(subtotal);

    let orderId = null, orderNo = null, token = crypto.randomBytes(16).toString('hex');
    for (let i = 0; i < 6 && !orderId; i++) {
      orderNo = `CM${manilaDateStamp()}-${crypto.randomInt(1000, 10000)}`;
      try {
        const [r] = await conn.query('INSERT INTO orders SET ?', [{
          order_no: orderNo,
          public_token: token,
          user_id: o.user_id || null,
          cashier_id: o.cashier_id || null,
          source: o.source,
          service_type: o.service_type,
          table_no: str(o.table_no, 20) || null,
          customer_name: str(o.customer_name, 120) || 'Walk-in',
          customer_phone: str(o.customer_phone, 30) || null,
          notes: str(o.notes, 300) || null,
          subtotal,
          total: subtotal,
          status: 'pending_payment',
          payment_status: 'unpaid',
        }]);
        orderId = r.insertId;
      } catch (e) {
        if (e.code !== 'ER_DUP_ENTRY') throw e;
      }
    }
    if (!orderId) throw new HttpError(500, 'Could not generate order number');

    await conn.query(
      'INSERT INTO order_items (order_id,product_id,name,price,qty,line_total) VALUES ?',
      [lines.map(([p, q, lt]) => [orderId, p.id, p.name, p.price, q, lt])]
    );
    await conn.commit();
    return { id: orderId, order_no: orderNo, public_token: token, total: subtotal };
  } catch (e) {
    await conn.rollback();
    throw e;
  } finally {
    conn.release();
  }
}

/**
 * Atomically flips an order to paid. Returns false if it was already paid (or cancelled),
 * which makes it safe against duplicate webhooks / double clicks.
 */
async function markPaid(conn, orderId, method, extra = {}) {
  const [r] = await conn.query(
    "UPDATE orders SET payment_status='paid', status='new', payment_method=?, paid_at=NOW(), cash_tendered=?, cash_change=? WHERE id=? AND payment_status<>'paid' AND status='pending_payment'",
    [method, extra.tendered ?? null, extra.change ?? null, orderId]
  );
  if (!r.affectedRows) return false;
  const [items] = await conn.query(
    'SELECT oi.product_id, oi.qty FROM order_items oi JOIN products p ON p.id=oi.product_id AND p.track_stock=1 WHERE oi.order_id=?',
    [orderId]
  );
  for (const it of items) {
    await conn.query('UPDATE products SET stock_qty=GREATEST(stock_qty-?,0) WHERE id=?', [it.qty, it.product_id]);
    await conn.query('INSERT INTO stock_movements (product_id,change_qty,reason,order_id) VALUES (?,?,?,?)', [it.product_id, -it.qty, 'sale', orderId]);
  }
  return true;
}

async function loadOrder(where, params) {
  const [[o]] = await pool.query(`SELECT * FROM orders WHERE ${where} LIMIT 1`, params);
  if (!o) return null;
  const [items] = await pool.query('SELECT product_id,name,price,qty,line_total FROM order_items WHERE order_id=?', [o.id]);
  o.items = items;
  return o;
}

/** Fields safe to show to customers */
function publicOrder(o) {
  return {
    id: o.id, order_no: o.order_no, public_token: o.public_token, service_type: o.service_type,
    table_no: o.table_no, customer_name: o.customer_name, notes: o.notes, subtotal: o.subtotal, total: o.total,
    status: o.status, payment_status: o.payment_status, payment_method: o.payment_method,
    cash_tendered: o.cash_tendered, cash_change: o.cash_change, paid_at: o.paid_at, created_at: o.created_at,
    source: o.source, items: o.items,
  };
}

module.exports = { createOrder, markPaid, loadOrder, publicOrder };
