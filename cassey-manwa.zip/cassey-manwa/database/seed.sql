-- Sample menu. Edit freely from the Admin dashboard afterwards.
INSERT IGNORE INTO categories (id, name, sort_order) VALUES
 (1,'Hot Coffee',1),(2,'Iced Coffee',2),(3,'Non-Coffee',3),(4,'Pastries',4),(5,'Meals',5);

INSERT INTO products (category_id, name, description, price, available, track_stock, stock_qty) VALUES
 (1,'Espresso','Rich double shot of espresso.',90.00,1,0,0),
 (1,'Americano','Espresso with hot water.',100.00,1,0,0),
 (1,'Cappuccino','Espresso, steamed milk and thick foam.',130.00,1,0,0),
 (1,'Cafe Latte','Smooth espresso with steamed milk.',130.00,1,0,0),
 (2,'Iced Americano','Chilled espresso over ice.',110.00,1,0,0),
 (2,'Iced Spanish Latte','Sweet condensed milk latte over ice.',150.00,1,0,0),
 (2,'Caramel Macchiato','Vanilla, milk, espresso and caramel drizzle.',160.00,1,0,0),
 (3,'Matcha Latte','Ceremonial-style matcha with milk.',150.00,1,0,0),
 (3,'Hot Chocolate','Rich cocoa with steamed milk.',120.00,1,0,0),
 (4,'Butter Croissant','Flaky, freshly baked.',85.00,1,1,20),
 (4,'Chocolate Chip Cookie','Soft and chewy.',65.00,1,1,30),
 (4,'Banana Bread Slice','Moist homemade banana bread.',75.00,1,1,15),
 (5,'Chicken Sandwich','Grilled chicken, lettuce and aioli on toasted bread.',180.00,1,1,10),
 (5,'Tuna Pasta','Creamy tuna pasta.',170.00,1,1,10);
