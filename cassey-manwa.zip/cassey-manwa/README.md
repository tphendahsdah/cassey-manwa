# CASSEY MANWA – Coffee Shop Management System

Customer ordering site · Cashier POS · Kitchen display · Admin dashboard · PayMongo **QR Ph** payments.
Stack: HTML/CSS/JS frontend, Node.js + Express backend, MySQL, PayMongo.

## Pages

| URL | Who | What |
|---|---|---|
| `/` | Customers | Menu, cart, dine-in/takeout checkout, QR Ph payment, live order tracking, receipt |
| `/login.html` | Everyone | Login / customer sign-up (staff accounts are created by admin) |
| `/pos` | Cashier, Admin | Sell items, QR Ph or cash, print receipts, today's orders (walk-in + online) |
| `/kitchen` | Kitchen, Cashier, Admin | New → Preparing → Ready → Completed (auto-refresh every 5 s) |
| `/admin` | Admin | Dashboard, orders & payments, products, categories, inventory, users, sales reports + CSV |

## 1. Run locally

Requirements: Node.js 18+ and MySQL 5.7+/8.

```bash
npm install
cp .env.example .env          # then edit .env
mysql -u root -p -e "CREATE DATABASE cassey_manwa CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
mysql -u root -p cassey_manwa < database/schema.sql
mysql -u root -p cassey_manwa < database/seed.sql        # optional sample menu
npm run create-admin -- "Your Name" you@example.com "A-Strong-Password"
npm start                                               # http://localhost:3000
```

Create cashier / kitchen accounts from **Admin → Employees & customers → Add staff**.

## 2. PayMongo QR Ph setup

1. Create a PayMongo account and complete activation. Make sure **QR Ph** is enabled for your account (Dashboard → Payment Methods).
2. Dashboard → Developers → API Keys. Put the **secret key** (`sk_test_…` first, `sk_live_…` later) in `PAYMONGO_SECRET_KEY`. Never put it in frontend code.
3. Dashboard → Developers → Webhooks → *Create webhook*:
   - URL: `https://YOUR-DOMAIN/api/webhooks/paymongo`
   - Events: `payment.paid`, `payment.failed`
   - Copy the signing secret (`whsk_…`) into `PAYMONGO_WEBHOOK_SECRET`.
4. `PAYMONGO_LIVE=false` with test keys, `true` with live keys (selects which signature PayMongo sends).
5. Test in PayMongo test mode first, then switch keys.

How payment works (nothing is ever simulated):

1. An order is created **unpaid**; the total is computed on the server from database prices.
2. The server creates a PayMongo Payment Intent for that exact amount with `qrph`, attaches a QR Ph payment method and shows the returned QR.
3. When the customer pays, PayMongo calls the webhook. The signature is verified (HMAC-SHA256), the intent is re-fetched from PayMongo to confirm `succeeded` and the amount, and only then the order is marked paid and sent to the kitchen. The customer/POS screen also polls PayMongo every few seconds as a fallback if a webhook is delayed.
4. Duplicate protection: unique webhook event IDs, unique payment intent / payment IDs, and an atomic `UPDATE … WHERE payment_status<>'paid'`, so retried webhooks or double clicks cannot double-pay or double-deduct stock.

> The QR Ph code in the screenshot you shared is a **static** QR. This system does not use it. It asks PayMongo for a **dynamic** QR with the exact amount for every order. If PayMongo changes the QR Ph response shape, the one place to adjust is `extractQr()` in `src/services/paymongo.js`. Check your account against the PayMongo docs when going live.

Refunds: do them in the PayMongo dashboard.

## 3. Security notes

- Passwords hashed with bcrypt (cost 12); sessions in an httpOnly, SameSite cookie (Secure in production); 12-hour expiry.
- Roles enforced on every API route (`admin`, `cashier`, `kitchen`, `customer`); disabled users are locked out immediately.
- Helmet + strict CSP (no inline scripts), rate limiting on login/sign-up/tracking, origin check on write requests, parameterized SQL everywhere, HTML-escaped output.
- Order tracking needs order number **and** phone; payment screens use an unguessable token.
- Secrets live only in `.env` (not in the web root). Do not upload `.env` to a public folder.

## 4. Deploy on GoDaddy

Node.js apps need either **GoDaddy Linux cPanel hosting with "Setup Node.js App"** (Deluxe/Ultimate/Maximum plans; check yours shows it in cPanel) or a **GoDaddy VPS**. GoDaddy's basic Economy/Windows plans and Website Builder cannot run this.

### Option A: cPanel hosting

1. **Database.** cPanel → *MySQL® Databases*: create a database and a user, add the user to the database with all privileges. Note the full names (they get a prefix like `cpuser_`).
2. cPanel → *phpMyAdmin* → select the database → *Import* `database/schema.sql` (the `CREATE DATABASE` lines are already commented out), then optionally `database/seed.sql`.
3. **Upload.** Zip the project **without `node_modules` and `.env`**. File Manager → create a folder such as `cassey-manwa` in your home directory (not inside `public_html`), upload and extract.
4. cPanel → *Setup Node.js App* → **Create Application**:
   - Node.js version: 18 or newer
   - Application mode: Production
   - Application root: `cassey-manwa`
   - Application URL: your domain
   - Application startup file: `app.js`
5. In the same screen add **environment variables** (the same names as `.env.example`): `NODE_ENV=production`, `DB_HOST=localhost`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`, `JWT_SECRET`, `PAYMONGO_SECRET_KEY`, `PAYMONGO_WEBHOOK_SECRET`, `PAYMONGO_LIVE`, `SHOP_NAME`, `SHOP_ADDRESS`, `SHOP_PHONE`. (Do not set `PORT`; the host sets it.)
6. Click **Run NPM Install**, then **Restart**.
7. **Create the admin:** use the *Enter to the virtual environment* command shown at the top of the Node.js app page in cPanel *Terminal*, then:
   `npm run create-admin -- "Your Name" you@example.com "A-Strong-Password"`
   (needs env vars or a `.env` file in the app root for the DB credentials; if you use a `.env` file, set its permissions to 600.)
8. **HTTPS.** cPanel → *SSL/TLS Status* → run AutoSSL so the site is on `https://`. PayMongo webhooks and secure cookies require HTTPS.
9. Create the PayMongo webhook with `https://YOUR-DOMAIN/api/webhooks/paymongo`.
10. Test: place an order from `/`, pay it in PayMongo test mode, confirm it reaches `/kitchen`, then print a receipt from `/pos`.

### Option B: GoDaddy VPS (Ubuntu)

```bash
sudo apt update && sudo apt install -y nginx mysql-server certbot python3-certbot-nginx
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt install -y nodejs
sudo npm i -g pm2
# create DB + user in MySQL, import database/schema.sql, upload project to /var/www/cassey-manwa
cd /var/www/cassey-manwa && npm ci --omit=dev && cp .env.example .env && nano .env
pm2 start app.js --name cassey && pm2 save && pm2 startup
# nginx: proxy_pass http://127.0.0.1:3000; (add proxy_set_header Host $host; X-Forwarded-Proto $scheme;)
sudo certbot --nginx -d yourdomain.com
```

## 5. Go-live checklist

- [ ] Strong, unique `JWT_SECRET`; `.env` outside the public web folder
- [ ] HTTPS active; `NODE_ENV=production`
- [ ] Live PayMongo key + live webhook secret + `PAYMONGO_LIVE=true`
- [ ] One small real QR Ph payment tested end to end (and refunded in PayMongo)
- [ ] Default/sample admin password changed; staff accounts created
- [ ] Daily database backup enabled (cPanel Backup or `mysqldump` cron)
- [ ] Printer set as default on the cashier computer (receipt is 80 mm friendly: browser print dialog → select printer)

## Project layout

```
app.js                  server entry (GoDaddy startup file)
src/db.js               MySQL pool (Asia/Manila time)
src/middleware/auth.js  JWT cookie + role checks
src/services/orders.js  order creation, atomic payment, stock deduction
src/services/paymongo.js QR Ph, settle, webhook verification
src/routes/*.js         public / staff (POS + kitchen) / admin APIs
database/*.sql          schema + sample menu
public/                 all pages, css, js
scripts/create-admin.js first admin account
```
