// Usage: node scripts/create-admin.js "Full Name" email@example.com "StrongPassword123"
require('dotenv').config();
const bcrypt = require('bcryptjs');
const pool = require('../src/db');

(async () => {
  const [name, email, password] = process.argv.slice(2);
  if (!name || !email || !password || password.length < 8) {
    console.error('Usage: node scripts/create-admin.js "Full Name" email password(min 8 chars)');
    process.exit(1);
  }
  const hash = await bcrypt.hash(password, 12);
  await pool.query(
    "INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?, 'admin') ON DUPLICATE KEY UPDATE password_hash=VALUES(password_hash), role='admin', active=1",
    [name, email.toLowerCase(), hash]
  );
  console.log('Admin ready:', email.toLowerCase());
  process.exit(0);
})().catch((e) => { console.error(e.message); process.exit(1); });
